import { NgModule } from '@angular/core';
import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ToastrModule } from 'ngx-toastr';
import { AppMaterialModule } from '../shared/app-material.module';

@NgModule({
  declarations: [LoginComponent],
  imports: [
    LoginRoutingModule,
    ToastrModule.forRoot(),
    AppMaterialModule,
    FlexLayoutModule.withConfig({addFlexToParent: false})
  ]
})
export class LoginModule { }
