import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

    loginForm: FormGroup;
    error = '';

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authService: AuthService
    ) {
        // redirect to home if already logged in
        if (this.authService.currentUserValue) {
            this.router.navigate(['/']);
        }
    }

    ngOnInit() {
        this.loginForm = new FormGroup( {
            email: new FormControl('', Validators.required),
            password: new FormControl('', Validators.required)
        });
    }

    hasError(controlName: string, errorName: string) {
        return this.loginForm.controls[controlName].hasError(errorName);
    }

    // convenience getter for easy access to form fields
	get f() { return this.loginForm.controls; }

    onSubmit() {
        if (this.loginForm.valid) {
            this.authService.login(this.f.email.value, this.f.password.value)
                .subscribe(
                    data => {
                        this.router.navigate(["/"]);
                    },
                    error => {
                        this.error = error;
                    });
        }
    }
}
