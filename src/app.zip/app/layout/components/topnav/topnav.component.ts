import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-topnav',
  templateUrl: './topnav.component.html',
  styleUrls: ['./topnav.component.scss']
})
export class TopnavComponent implements OnInit {

  constructor(public router: Router,private authService: AuthService) {
  }

  ngOnInit() {
  }

  onLoggedout() {
      this.authService.logout();
      this.router.navigate(['/login']);
  }
}
