export class User {
    email: string;
    firstName?: string;
    lastName?: string;
    contactNumber?: string;
    regCode?: string;
    linkedinUrl?: string;
    roles?: string;
    active?: number;
    token: string;
    createdAt?: Date;
    updatedAt?: Date;
}
