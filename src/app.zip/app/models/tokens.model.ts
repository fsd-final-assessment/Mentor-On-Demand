export class Tokens {
    token: string;
    refreshToken: string;
}
