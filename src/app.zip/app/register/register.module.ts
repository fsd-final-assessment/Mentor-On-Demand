import { NgModule } from '@angular/core';

import { RegisterRoutingModule } from './register-routing.module';
import { RegisterComponent } from './register.component';
import { AppMaterialModule } from '../shared/app-material.module';
import { FlexLayoutModule } from '@angular/flex-layout';


@NgModule({
  declarations: [RegisterComponent],
  imports: [
    RegisterRoutingModule,
    AppMaterialModule,
    FlexLayoutModule.withConfig({addFlexToParent: false})
  ]
})
export class RegisterModule { }
