import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  loginForm: FormGroup;
  error = '';
  selectedIndex:number;
    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authService: AuthService
    ) {
        // redirect to home if already logged in
        if (this.authService.currentUserValue) {
            this.router.navigate(['/']);
        }
    }

    ngOnInit() {
      this.selectedIndex = 0;
        this.loginForm = new FormGroup( {
            email: new FormControl('', Validators.required),
            password: new FormControl('', Validators.required),
            firstName: new FormControl('', Validators.required),
            lastName: new FormControl('', Validators.required),
            contactNumber: new FormControl(''),
            linkedinUrl: new FormControl('')
        });
    }
    selectedIndexChange(index){
      this.selectedIndex = index;
      this.loginForm.patchValue({
        email: this.f.email.value,
        password: this.f.password.value,
        firstName: this.f.firstName.value,
        lastName: this.f.lastName.value,
        contactNumber: this.f.contactNumber.value,
        linkedinUrl: this.f.linkedinUrl.value
      });
    }
    hasError(controlName: string, errorName: string) {
        return this.loginForm.controls[controlName].hasError(errorName);
    }

    // convenience getter for easy access to form fields
	get f() { return this.loginForm.controls; }

    onSubmit() {
        if (this.loginForm.valid) {
            this.authService.register(this.f.email.value, this.f.password.value,this.f.firstName.value,this.f.lastName.value,this.f.contactNumber.value,this.f.linkedinUrl.value,this.selectedIndex==0?'USER':'MENTOR')
                .subscribe(
                    data => {
                        this.router.navigate(["/"]);
                    },
                    error => {
                        this.error = error;
                    });
        }
    }
}
